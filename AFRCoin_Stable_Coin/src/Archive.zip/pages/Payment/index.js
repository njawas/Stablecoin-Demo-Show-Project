import React, { useState } from 'react'

const PaymentIndex = props => {
    return(
        <></>
    )
}

export default PaymentIndex